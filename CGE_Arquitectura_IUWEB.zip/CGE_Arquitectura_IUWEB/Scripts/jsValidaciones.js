/*********************************************************
Descripcion:	validaciones para campos de texto
Restriccion: debe llamarse en el onsubmit de la forma o en el onblur del campo de texto 
*********************************************************/
var _Errmsg = "";
var _vfoco = null;
var d = new Date();
var msg = "REPUBLICA DEL ECUADOR. CONTRALORIA GENERAL DEL ESTADO. Copyright Direcci\xf3n de Tecnolog\xeda de Informaci\xf3n y Comunicaciones - " + d.getFullYear();

function llenaPie() {
    document.getElementById("pie").innerText = msg;
}

function CambiarTablaJQ() {
    var grid = $("#gvwData");
    if (grid.find("tr").length > 2) {
        grid.dataTable({
            "sPaginationType": "full_numbers",
            "aoColumnDefs": [
                { "bSortable": true, "aTargets": [1] }
            ],
            "aaSorting": [[1, "asc"]],
            "iDisplayLength": 5,
            "aLengthMenu": [[5, 10, 15], [5, 10, 15]]
        });
    }
}

/*Valida sqlInjection en los campos ingresados*/
function validaSQLInjection(evt) {
    $(':text,textarea').each(function () {
        var strTextoIngresado = $($(this)).val();

        var arrayPalabrasNoPermitidas = new Array("insert ", "delete ", "truncate ", "drop ", "execute ", " into ", "select ", "'", "like ", "grant ", "deny ");
        if (strTextoIngresado != "") {
            for (var i = 0; i < arrayPalabrasNoPermitidas.length; i++) {
                if (strTextoIngresado.toLowerCase().indexOf(arrayPalabrasNoPermitidas[i]) > -1) {
                    $($(this)).val("");
                    alert("Ha ingresado texto peligroso para la integridad de la informaci\xf3n en la Aplicaci\xf3n Web");
                    if (document.all) {
                        evt.returnValue = false;
                        evt.keyCode = 0;
                    }
                    else {
                        if (evt.cancelable) {
                            evt.preventDefault();
                        }
                    }

                }
            }
        }
    });
}


window.history.forward(1);

function Click() {
    //Control para inhabilitar el uso del Click Derecho
    if (navigator.appName == 'Netscape' && event.which == 3) {
        alert(msg);
        //return false;
    }
    else if (navigator.appName == 'Microsoft Internet Explorer' && event.button == 2) {
        alert(msg); //- Si no quieres asustar al usuario que utiliza IE,  entonces quita esta linea...
        //- Aunque realmente se lo merezca...
        //return false;
    }
    validaSQLInjection(event);
}


document.onmousedown = Click

document.onkeydown = function () { Verificar(event) };

document.oncontextmenu = function () { alert(msg); return false }


function Mensaje(texto) {
    alert(texto);
}

function AbrirVentana(pagina) {
    var opciones = "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, width=1000, height=700, top=85, left=140";
    window.open(pagina, "", opciones);
}



function Verificar(evt) {
    var tecla = null;
    if (document.all) {
        tecla = evt.keyCode
    }
    else
        tecla = evt.which;
    if (tecla == 116) {
        alert("F5 deshabilitado!");

        if (document.all) {
            evt.returnValue = false;
            evt.keyCode = 0;
        }
        else {
            if (evt.cancelable) {
                evt.preventDefault();
            }
        }
    }
    if (tecla == 13) {
        validaSQLInjection(evt);
    }
}

function VerificarConEnter(evt) {
    var tecla = null;
    if (document.all)
        tecla = evt.keyCode
    else
        tecla = evt.which;
    if (tecla == 116) {
        alert("F5 deshabilitado!");

        if (document.all) {
            evt.returnValue = false;
            evt.keyCode = 0;
        }
        else {
            if (evt.cancelable) {
                evt.preventDefault();
            }
        }
    }

    if (tecla == 13) {
        //alert("Enter deshabilitado!");

        if (document.all) {
            evt.returnValue = false;
            evt.keyCode = 0;
        }
        else {
            if (evt.cancelable) {
                evt.preventDefault();
            }
        }
    }
    //validaSQLInjection(evt);  
}

function ValidaCampo(IDObj, mensaje) {
    if (document.getElementById(IDObj).value == "") {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    try {
        MostarAlertaError(IDObj, false); //ocultar el error
    } catch (e) { }
    return true;
}

function ValidaCampoHTML(IDObj, mensaje) {
    if (Trim(document.getElementById(IDObj).innerHTML) == "") {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    try {
        MostarAlertaError(IDObj, false); //ocultar el error
    } catch (e) { }
    return true;
}

function ValidaComboValor(IDObj, valor, mensaje) {
    var indice = document.getElementById(IDObj).selectedIndex;
    var valorCombo = "";
    if (indice === -1)
        valorCombo = valor;
    else
        var valorCombo = document.getElementById(IDObj).options[indice].value

    if (valorCombo == valor) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    MostarAlertaError(IDObj, false); //ocultar el error
    return true;
}

function ValidaLongitud(IDObj, mensaje, min) {
    if (document.getElementById(IDObj).value != "" && document.getElementById(IDObj).value.length < min) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    MostarAlertaError(IDObj, false); //ocultar el error
    return true;
}

function ValidaLongitud(IDObj, mensaje, min, max) {
    if (document.getElementById(IDObj).value != "" && (document.getElementById(IDObj).value.length < min || document.getElementById(IDObj).value.length > max)) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    MostarAlertaError(IDObj, false); //ocultar el error
    return true;
}

function ValidaRango(IDObj, mensaje, min, max) {
    if (document.getElementById(IDObj).value != "" && (document.getElementById(IDObj).value < min || document.getElementById(IDObj).value > max)) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;

        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    MostarAlertaError(IDObj, false);
    return true;
}

function ValidaIgualdad(IDObj1, IDObj2, mensaje) {
    if (document.getElementById(IDObj1).value != "" && document.getElementById(IDObj2).value != "" && (document.getElementById(IDObj1).value != document.getElementById(IDObj2).value)) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj2) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj1, true);
        return false;
    }
    MostarAlertaError(IDObj1, false);
    return true;
}

function ValidaMesAnio(IDObj, mensaje) {
    var strFormato = /((0[123456789])|(1[012]))\/\d\d\d\d/
    if (!strFormato.test(document.getElementById(IDObj).value)) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj, true);
        return false;
    }
    MostarAlertaError(IDObj, false);
    return true;
}


function comprobarSiBisisesto(anio) {
    if ((anio % 100 != 0) && ((anio % 4 == 0) || (anio % 400 == 0))) {
        return true;
    }
    else {
        return false;
    }
}

function ValidaMesYDia(mes, dia, anio) {
    switch (mes) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            numDias = 31;
            break;
        case 4: case 6: case 9: case 11:
            numDias = 30;
            break;
        case 2:
            if (comprobarSiBisisesto(anio)) {
                numDias = 29
            }
            else {
                numDias = 28
            };
            break;
        default:
            return false;
    }


    if (dia > numDias || dia == 0) {
        return false;
    }

    return true;
}

function ValidaFecha(IDObj1, mensaje, formato) {
    var fecha = document.getElementById(IDObj1).value
    var mes = ""
    var anio = ""
    var dia = ""
    if (formato == null || formato == "") {
        if (fecha.length != 10) {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            return false;
        }
        var f1 = new Date()
        f1.setDate(eval(fecha.substr(0, 2)));
        f1.setMonth(eval(fecha.substr(3, 2)) - 1);
        f1.setFullYear(eval(fecha.substr(6)));

        mes = eval(fecha.substr(3, 2));
        anio = eval(fecha.substr(6));
        dia = eval(fecha.substr(0, 2));


        if (f1.getFullYear() != eval(fecha.substr(6))) {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            //pintar el error si existe
            MostarAlertaError(IDObj1, true);
            return false;
        }

        if (!ValidaMesYDia(mes, dia, anio)) {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            //pintar el error si existe
            MostarAlertaError(IDObj1, true);
            return false;
        }

        /*if (f1.getDate() != eval(fecha.substr(0, 2)) || f1.getMonth() != (eval(fecha.substr(3, 2)) - 1) || f1.getFullYear() != eval(fecha.substr(6))) 
        {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            //pintar el error si existe
            MostarAlertaError(IDObj1, true);
            return false;
        }*/
    }
    else {
        if (fecha.length != formato.length) {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            /*pintar el error si existe*/
            MostarAlertaError(IDObj1, true);
            return false;
        }
        formato = formato.replace(/-/gi, "");
        if (formato.toUpperCase() == "YYYYMMDD") {
            var fecha = document.getElementById(IDObj1).value
            fecha = fecha.replace(/-/gi, "");
            var f1 = new Date()
            f1.setFullYear(eval(fecha.substr(0, 4)));
            f1.setMonth(eval(fecha.substr(4, 2)) - 1);
            f1.setDate(eval(fecha.substr(6)));

            anio = eval(fecha.substr(0, 4));
            mes = eval(fecha.substr(4, 2));
            dia = eval(fecha.substr(6));


            if (f1.getFullYear() != eval(fecha.substr(0, 4))) {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }

            if (!ValidaMesYDia(mes, dia, anio)) {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }

            /*
            if (f1.getDate() != eval(fecha.substr(6)) || f1.getMonth() != (eval(fecha.substr(4, 2)) - 1) || f1.getFullYear() != eval(fecha.substr(0, 4))) 
            {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }*/
            return true;
        }
        else if (upper(formato.toUpperCase()) = "DDMMYYYY") {
            var f1 = new Date()

            f1.setDate(eval(fecha.substr(0, 2)));
            f1.setMonth(eval(fecha.substr(3, 2)) - 1);
            f1.setFullYear(eval(fecha.substr(6)));

            dia = f1.setDate(eval(fecha.substr(0, 2)));
            mes = f1.setMonth(eval(fecha.substr(3, 2)));
            anio = f1.setFullYear(eval(fecha.substr(6)));

            /*
            if (f1.getDate() != eval(fecha.substr(0, 2)) || f1.getMonth() != (eval(fecha.substr(3, 2)) - 1) || f1.getFullYear() != eval(fecha.substr(6))) {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }*/

            if (f1.getFullYear() != eval(fecha.substr(6))) {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }

            if (!ValidaMesYDia(mes, dia, anio)) {
                _Errmsg += "- " + mensaje + "\n";
                _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
                //pintar el error si existe
                MostarAlertaError(IDObj1, true);
                return false;
            }
        }
        else
            alert('formato no soportado');
    }
    MostarAlertaError(IDObj1, false);
    return true;
}

function ValidaYYYYMMDD(IDObj1, mensaje) {
    var fecha = document.getElementById(IDObj1).value
    if (fecha.length != 8) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj1, true);
        return false;
    }
    var f1 = new Date()
    f1.setFullYear(eval(fecha.substr(0, 4)));
    f1.setMonth(eval(fecha.substr(4, 2)) - 1);
    f1.setDate(eval(fecha.substr(6)));
    if (f1.getDate() != eval(fecha.substr(6)) || f1.getMonth() != (eval(fecha.substr(4, 2)) - 1) || f1.getFullYear() != eval(fecha.substr(0, 4))) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        /*pintar el error si existe*/
        MostarAlertaError(IDObj1, true);
        return false;
    }
    /*pintar el error si existe*/
    MostarAlertaError(IDObj1, false);
    return true;
}

function ValidaMFecha(IDObj1, IDObj2, mensaje) {
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1 = new Date()
    var f2 = new Date()
    f1.setDate(eval(fecha1.substr(0, 2)));
    f1.setMonth(eval(fecha1.substr(3, 2)) - 1);
    f1.setFullYear(eval(fecha1.substr(6)));
    f2.setDate(eval(fecha2.substr(0, 2)));
    f2.setMonth(eval(fecha2.substr(3, 2)) - 1);
    f2.setFullYear(eval(fecha2.substr(6)));
    if (f1 <= f2) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        return false;
    }
    return true;
}

function ValidaFechaMayorFormatoWeb(IDObj1, IDObj2, mensaje) {
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1 = new Date()
    var f2 = new Date()
    f1.setFullYear(eval(fecha1.substr(0, 4)));
    f1.setMonth(eval(fecha1.substr(5, 2)) - 1);
    f1.setDate(eval(fecha1.substr(8)));

    f2.setFullYear(eval(fecha2.substr(0, 4)));
    f2.setMonth(eval(fecha2.substr(5, 2)) - 1);
    f2.setDate(eval(fecha2.substr(8)));
    if (f1 > f2) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        return false;
    }
    return true;
}

function ValidaMIFecha(IDObj1, IDObj2, mensaje) {
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1 = new Date()
    var f2 = new Date()
    f1.setDate(eval(fecha1.substr(0, 2)));
    f1.setMonth(eval(fecha1.substr(3, 2)) - 1);
    f1.setFullYear(eval(fecha1.substr(6)));
    f2.setDate(eval(fecha2.substr(0, 2)));
    f2.setMonth(eval(fecha2.substr(3, 2)) - 1);
    f2.setFullYear(eval(fecha2.substr(6)));
    if (f1 < f2) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        return false;
    }
    return true;
}
////
function ValidaMFechaYYYYMMDD(IDObj1, IDObj2, mensaje) {
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1 = new Date()
    var f2 = new Date()
    f1.setFullYear(eval(fecha1.substr(0, 4)));
    f1.setMonth(eval(fecha1.substr(4, 2)) - 1);
    f1.setDate(eval(fecha1.substr(6)));
    f2.setFullYear(eval(fecha2.substr(0, 4)));
    f2.setMonth(eval(fecha2.substr(4, 2)) - 1);
    f2.setDate(eval(fecha2.substr(6)));
    if (f1 <= f2) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        return false;
    }
    return true;
}

function ValidaMIFechaYYYYMMDD(IDObj1, IDObj2, mensaje) {
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1 = new Date()
    var f2 = new Date()
    f1.setFullYear(eval(fecha1.substr(0, 4)));
    f1.setMonth(eval(fecha1.substr(4, 2)) - 1);
    f1.setDate(eval(fecha1.substr(6)));
    f2.setFullYear(eval(fecha2.substr(0, 4)));
    f2.setMonth(eval(fecha2.substr(4, 2)) - 1);
    f2.setDate(eval(fecha2.substr(6)));
    if (f1 < f2) {
        _Errmsg += "- " + mensaje + "\n";
        _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
        return false;
    }
    return true;
}
function ValidaNumeroOnPaste(campo) {
    var texto = new String(window.clipboardData.getData("Text"));
    if (texto != '') {
        if (isNaN(texto)) //no es numero
        {
            window.clipboardData.setData("Text", "");
            campo.value = "";
            campo.focus();
            return false;
        }
        else //si es numero
        {
        }
    }
    return true;
}

function ComparaFechas(IDObj1, IDObj2, mensaje, formato, comparacion) {
    var validarFecha = true;
    var fecha1 = document.getElementById(IDObj1).value
    var fecha2 = document.getElementById(IDObj2).value
    var f1, f2

    if (fecha1 == '' || fecha2 == '') return true;
    if (formato.length != 10) validarFecha = false;
    if (comparacion != '>' && comparacion != '<' && comparacion != '>=' && comparacion != '<=' && comparacion != '==') {
        mensaje = mensaje + '\n- Comparacion no valida use: > < >= <= ==';
    }

    formato = formato.toUpperCase();
    posDia = formato.indexOf("DD");
    posMes = formato.indexOf("MM");
    posAnio = formato.indexOf("YYYY");

    if (posDia < 0 || posMes < 0 || posAnio < 0) validarFecha = false;

    if (validarFecha) {
        vDia = fecha1.substr(posDia, 2);
        vMes = fecha1.substr(posMes, 2);
        vAnio = fecha1.substr(posAnio, 4);
        f1 = new Date(vAnio, vMes - 1, vDia);
        if (f1.getFullYear() != parseInt(vAnio - 0) || (parseInt(f1.getMonth()) + 1) != parseInt(vMes - 0) || f1.getDate() != parseInt(vDia - 0)) {
            mensaje = mensaje + '\n- Fecha invalida';
        }

        vDia = fecha2.substr(posDia, 2);
        vMes = fecha2.substr(posMes, 2);
        vAnio = fecha2.substr(posAnio, 4);
        f2 = new Date(vAnio, vMes - 1, vDia);
        if (f2.getFullYear() != parseInt(vAnio - 0) || (parseInt(f2.getMonth()) + 1) != parseInt(vMes - 0) || f2.getDate() != parseInt(vDia - 0)) {
            mensaje = mensaje + '\n- Fecha invalida';
        }

        if (!eval('f1' + comparacion + 'f2')) {
            _Errmsg += "- " + mensaje + "\n";
            _vfoco = (_vfoco == (void 0)) ? document.getElementById(IDObj1) : _vfoco;
            return false;
        }
        return true;
    } else {
        mensaje = mensaje + '\n- Formato no validable';
    }
}

// Solo permite n�meros
function KeyNumber(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;

    if (keyCode == 0 || keyCode == 8 || keyCode == 13) {
        return;
    }

    if (keyCode < 48 || keyCode > 57) {
        if (document.all) {
            evt.keyCode = 0;
        }
        else {
            evt.preventDefault();
        }
    }

}

// Solo permite n�meros y el punto
function KeyMoney(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    //Uso el punto como decimal
    if ((keyCode < 48 || keyCode > 57) && keyCode != 46) {
        if (document.all) {
            evt.keyCode = 0;
        }
        else {
            evt.preventDefault();
        }
    }
}

// No permite nada
function KeyLock(evt) {
    if (document.all) {
        evt.returnValue = false;
        evt.keyCode = 0;
    }
    else {
        if (evt.cancelable) {
            evt.preventDefault();

        }
    }
}

// Solo permite n�meros y el /
function KeyDate(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (String.fromCharCode(keyCode) == "/")
        return;
    KeyNumber(evt);
}

// Solo permite n�meros, parentesis, -, ext
function KeyFone(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (String.fromCharCode(keyCode) == "-" || String.fromCharCode(keyCode) == "(" || String.fromCharCode(keyCode) == ")" || KeyLower(String.fromCharCode(keyCode)) == "e" || KeyLower(String.fromCharCode(keyCode)) == "x" || KeyLower(String.fromCharCode(keyCode)) == "t" || KeyLower(String.fromCharCode(keyCode)) == " ")
        return;

    KeyNumber(evt);
}

// Solo permite n�meros y -
function KeyCB(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (String.fromCharCode(keyCode) == "-")
        return;

    KeyNumber(evt);
}

// Solo permite n�meros y :
function KeyTime(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (String.fromCharCode(keyCode) == ":" || LCase(String.fromCharCode(keyCode)) == "a" || LCase(String.fromCharCode(keyCode)) == "m" || LCase(String.fromCharCode(keyCode)) == "p" || String.fromCharCode(keyCode) == " ")
        return;

    KeyNumber(evt);
}

// Solo permite letras de la a - z
function KeyChar(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (LCase(String.fromCharCode(keyCode)) < "a" || LCase(String.fromCharCode(keyCode)) > "z") {
        if (document.all) {
            evt.keyCode = 0;
        }
        else {
            evt.preventDefault();
        }
    }

}

// Solo permite letras y el espacio
/*function KeyString(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;

    if (keyCode == 13)
        return;
    if ((KeyLower(String.fromCharCode(keyCode)) > "a" || KeyLower(String.fromCharCode(keyCode)) < "z") && keyCode != 32) {
        if (document.all) {
            evt.keyCode = 0;
        }
        else {
            evt.preventDefault();
        }
    }
    
        
}*/

function KeyString(e) {
    opc = false;
    tecla = (document.all) ? event.keyCode : e.which;

    if (tecla == 0) { opc = true; } // permitir las teclas de funciones F1, F2, Insert, etc.
    if (tecla == 8) { opc = true; } // tecla backspace
    if (tecla == 13) { opc = true; } // evento_enter() } // tecla enter (si se quiere hacer algun evento)
    if ((tecla >= 97) && (tecla <= 122))
    { opc = true; }
    if ((tecla >= 65) && (tecla <= 90))
    { opc = true; }
    if (tecla == 32)
    { opc = true; }
    //alert(opc);
    if (!opc)
        event.keyCode = 0;
    return opc;
}


// transforma a may�sculas
function KeyUpper(evt) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;

    if (keyCode == 9 || keyCode == 0) return true;
    if (keyCode == 8) return true;

    /*if (String.fromCharCode(keyCode) >= "a" && String.fromCharCode(keyCode) <= "z") {
    if (document.all) {
    evt.keyCode = evt.keyCode - 32;
    }
    else {
    evt.preventDefault();
    evt.which = evt.which - 32;
    }
    }*/
    /*if (document.all)
    evt.keyCode = String.fromCharCode(keyCode).toLocaleUpperCase().charCodeAt(0);
    else
    evt.setKeyChar(String.fromCharCode(keyCode).toLocaleUpperCase().charCodeAt(0));
    */

    if (!document.all) {
        var pst = evt.currentTarget.selectionStart;
        var string_start = evt.currentTarget.value.substring(0, pst);
        var string_end = evt.currentTarget.value.substring(pst, evt.currentTarget.value.length);
        evt.currentTarget.value = string_start + String.fromCharCode(keyCode).toUpperCase() + string_end;
        evt.currentTarget.selectionStart = pst + 1;
        evt.currentTarget.selectionEnd = pst + 1;
        evt.stopPropagation();
        if (evt.cancelable) { evt.preventDefault(); }
        return false;
    }
    else {
        evt.keyCode = String.fromCharCode(keyCode).toLocaleUpperCase().charCodeAt(0);
    }

    //obj.value = obj.value.toUpperCase();
}

// transforma a min�sculas
function KeyLower(evt, obj) {
    var keyCode = null;
    if (document.all)
        keyCode = evt.keyCode
    else
        keyCode = evt.which;
    if (keyCode == 13)
        return;
    if (String.fromCharCode(keyCode) >= "A" && String.fromCharCode(keyCode) <= "Z") {
        if (document.all) {
            evt.keyCode = evt.keyCode + 32;
        }
        else {
            evt.preventDefault();
            evt.which = evt.which + 32;
        }
    }
    //obj.value = obj.value.toLowerCase();  

}

function Trim(str) {
    var resultStr = "";
    resultStr = TrimLeft(str);
    resultStr = TrimRight(resultStr);
    return resultStr;
}

function TrimLeft(str) {
    var resultStr = "";
    var i = len = 0;
    // Return immediately if an invalid value was passed in
    if (str + "" == "undefined" || str == null)
        return null;
    // Make sure the argument is a string
    str += "";
    if (str.length == 0)
        resultStr = "";
    else {
        // Loop through string starting at the beginning as long as there
        // are spaces.
        //             len = str.length - 1;
        len = str.length;

        while ((i <= len) && (str.charAt(i) == " "))
            i++;
        // When the loop is done, we're sitting at the first non-space char,
        // so return that char plus the remaining chars of the string.
        resultStr = str.substring(i, len);
    }
    return resultStr;
}


function TrimRight(str) {
    var resultStr = "";
    var i = 0;
    // Return immediately if an invalid value was passed in
    if (str + "" == "undefined" || str == null)
        return null;
    // Make sure the argument is a string
    str += "";

    if (str.length == 0)
        resultStr = "";
    else {
        // Loop through string starting at the end as long as there
        // are spaces.
        i = str.length - 1;
        while ((i >= 0) && (str.charAt(i) == " "))
            i--;

        // When the loop is done, we're sitting at the last non-space char,
        // so return that char plus all previous chars of the string.
        resultStr = str.substring(0, i + 1);
    }

    return resultStr;
}

function ConvierteMayusculas(str) {
    var resultStr = "";
    var i = 0;
    // Return immediately if an invalid value was passed in
    if (str + "" == "undefined" || str == null)
        return null;
    // Make sure the argument is a string
    str += "";

    if (str.length == 0)
        resultStr = "";
    else {
        resultStr = str;
        resultStr = resultStr.toLocaleUpperCase();
    }

    return resultStr;
}

function MostarAlertaError(idObjeto, mostrar) {
    var obj = $("#" + idObjeto);
    if (obj.length > 0) {
        var objeto = obj[0];
        if (mostrar) {
            if (objeto.type == "select-one" && objeto.parentNode.tagName == "SPAN") {
                objeto.parentNode.className = "errorObligatorio";
            } else {
                $("#" + idObjeto).addClass("errorObligatorio");
            }
        } else {
            if (objeto.type == "select-one" && objeto.parentNode.tagName == "SPAN")
                objeto.parentNode.className = "";
            else
                $("#" + idObjeto).removeClass("errorObligatorio");
        }
    }
}

