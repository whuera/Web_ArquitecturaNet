// Title: Timestamp picker
// Description: See the demo at url
// URL: http://www.geocities.com/tspicker/
// Version: 1.0.a (Date selector only)
// Date: 12-12-2001 (mm-dd-yyyy)
// Author: Denis Gritcyuk <denis@softcomplex.com>; <tspicker@yahoo.com>
// Notes: Permission given to use this script in any kind of applications if
//    header lines are left unchanged. Feel free to contact the author
//    for feature requests and/or donations

//Modificado para las fechas en espa�ol

function show_calendar4(str_target, str_datetime) {
	var arr_months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
	var week_days = ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"];
	var n_weekstart = 1; // day week starts from (normally 0 or 1)

	var dt_datetime = (str_datetime == null || str_datetime =="" ?  new Date() : str2dt4(str_datetime));
	var dt_prev_month = new Date(dt_datetime);
	dt_prev_month.setMonth(dt_datetime.getMonth()-1);
	var dt_next_month = new Date(dt_datetime);
	dt_next_month.setMonth(dt_datetime.getMonth()+1);
	var dt_firstday = new Date(dt_datetime);
	dt_firstday.setDate(1);
	dt_firstday.setDate(1-(7+dt_firstday.getDay()-n_weekstart)%7);
	var dt_lastday = new Date(dt_next_month);
	dt_lastday.setDate(0);
	
	// html generation (feel free to tune it for your particular application)
	// print calendar header
	var str_buffer = new String (
		"<html>\n"+
		"<head>\n"+
		"	<title>Calendario</title>\n"+
		"<script language=javascript>\n"+
		"function go_fecha(fecha){\n"+
		"window.opener."+str_target+".value=fecha;\n"+
		"window.opener."+str_target+".focus();\n"+
		"window.opener."+str_target+".select();\n"+
		"window.close();\n"+
		"}\n"+
		"</script>\n"+
		"</head>\n"+
		"<body bgcolor=\"White\">\n"+
		"<table class=\"clsOTable\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n"+
		"<tr><td bgcolor=\"#4682B4\">\n"+
		"<table cellspacing=\"1\" cellpadding=\"3\" border=\"0\" width=\"100%\">\n"+
		"<tr>\n	<td bgcolor=\"#4682B4\"><a href=\"javascript:window.opener.show_calendar4('"+
		str_target+"', '"+ dt2dtstr4(dt_prev_month)+"');\">"+
		"<img src=\"../../CGE_Arquitectura_WEB/Imagenes/imgPrev.gif\" width=\"16\" height=\"16\" border=\"0\"" +
		" alt=\"mes anterior\"></a></td>\n"+
		"	<td bgcolor=\"#4682B4\" colspan=\"5\">"+
		"<font color=\"white\" face=\"tahoma, verdana\" size=\"2\">"
		+arr_months[dt_datetime.getMonth()]+" "+dt_datetime.getFullYear()+"</font></td>\n"+
		"	<td bgcolor=\"#4682B4\" align=\"right\"><a href=\"javascript:window.opener.show_calendar4('"
		+str_target+"', '"+dt2dtstr4(dt_next_month)+"');\">"+
		"<img src=\"../../CGE_Arquitectura_WEB/Imagenes/imgNext.gif\" width=\"16\" height=\"16\" border=\"0\"" +
		" alt=\"mes siguiente\"></a></td>\n</tr>\n"
	);

	var dt_current_day = new Date(dt_firstday);
	// print weekdays titles
	str_buffer += "<tr>\n";
	for (var n=0; n<7; n++)
		str_buffer += "	<td bgcolor=\"#87CEFA\">"+
		"<font color=\"white\" face=\"tahoma, verdana\" size=\"2\">"+
		week_days[(n_weekstart+n)%7]+"</font></td>\n";
	// print calendar table
	str_buffer += "</tr>\n";
	while (dt_current_day.getMonth() == dt_datetime.getMonth() ||
		dt_current_day.getMonth() == dt_firstday.getMonth()) {
		// print row heder
		str_buffer += "<tr>\n";
		for (var n_current_wday=0; n_current_wday<7; n_current_wday++) {
				if (dt_current_day.getDate() == dt_datetime.getDate() &&
					dt_current_day.getMonth() == dt_datetime.getMonth())
					// print current date
					str_buffer += "	<td bgcolor=\"#FFB6C1\" align=\"right\">";
				else if (dt_current_day.getDay() == 0 || dt_current_day.getDay() == 6)
					// weekend days
					str_buffer += "	<td bgcolor=\"#DBEAF5\" align=\"right\">";
				else
					// print working days of current month
					str_buffer += "	<td bgcolor=\"white\" align=\"right\">";

				if (dt_current_day.getMonth() == dt_datetime.getMonth())
					// print days of current month
					str_buffer += "<a href=\"javascript:go_fecha('"+dt2dtstr4(dt_current_day)+"');\">"+
					"<font color=\"black\" face=\"tahoma, verdana\" size=\"2\">";
				else 
					// print days of other months
					str_buffer += "<a href=\"javascript:go_fecha('"+dt2dtstr4(dt_current_day)+"');\">"+
					"<font color=\"gray\" face=\"tahoma, verdana\" size=\"2\">";
                    					
				str_buffer += dt_current_day.getDate()+"</font></a></td>\n";
				dt_current_day.setDate(dt_current_day.getDate()+1);
		}
		// print row footer
		str_buffer += "</tr>\n";
	}
	// print calendar footer
	str_buffer +=
		"</table>\n" +
		"</tr>\n</td>\n</table>\n" +
		"</body>\n" +
		"</html>\n";

	var vWinCal = window.Calendar;
	if (vWinCal + "" == "undefined") {
	    vWinCal = window.open("", "Calendar", "width=200px,height=220px,status=no,resizable=yes,top=" + event.screenY + "px,left=" + (event.screenX) + "px");
	} else {
		try {
			var docAux = vWinCal.document;
} catch (e) {
vWinCal = window.open("", "Calendar", "width=200px,height=220px,status=no,resizable=yes,top=" + event.screenY + "px,left=" + (event.screenX) + "px");
		}
	}
    vWinCal.opener = self;
	window.Calendar = vWinCal;
	vWinCal.focus();
	var calc_doc = vWinCal.document;
	calc_doc.write (str_buffer);
	calc_doc.close();
}
// datetime parsing and formatting routimes. modify them if you wish other datetime format
function str2dt4 (str_datetime) {

var fecha=str_datetime;
var slash=fecha.search("/");
var dia=fecha.substring(0,slash);
fecha=str_datetime.substring(slash+1,fecha.length);

slash=fecha.search("/");
var mes=fecha.substring(0,slash);
var anio=fecha.substring(slash+1,fecha.length);
str_datetime=dia+"/"+mes+"/"+anio;

	var re_date = /^(\d+)\/(\d+)\/(\d+)$/;
	if (!re_date.exec(str_datetime))
		return alert("Formato de fecha inv&aacute;lido: "+ str_datetime);
	return (new Date (RegExp.$3, RegExp.$2-1, RegExp.$1));
}
function dt2dtstr4 (dt_datetime) {
    return (new String(LPad(dt_datetime.getDate(), 2, "0") + "/" + LPad((dt_datetime.getMonth() + 1), 2, "0") + "/" + dt_datetime.getFullYear()));
}

function LPad(ContentToSize, PadLength, PadChar) {
    var PaddedString = ContentToSize.toString();
    var tamanio = ContentToSize.toString().length + 1;
    for (i = tamanio; i <= PadLength; i++) {
        PaddedString = PadChar + PaddedString;
    }
    return PaddedString;
}


function MuestraCalendario(id) {
    $(function () {
        $("#" + id).datepicker({
            changeMonth: true,
            changeYear: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            showOn: "button",
            buttonImage: "../Imagenes/imgCalendario.gif",
            buttonImageOnly: true
        });
        $("#" + id).datepicker("option", { dateFormat: "yy-mm-dd" });
    });
}