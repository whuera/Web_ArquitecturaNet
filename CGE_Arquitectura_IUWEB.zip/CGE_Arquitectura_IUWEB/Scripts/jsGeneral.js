﻿/*MuestraCalendario-----------------------------------------------------------------------------------------
id: id del objeto que funcionará como tipo fecha
directorio: url en donde se encuentra la imagen
Ej: MuestraCalendario('txtFecha', '')
----------------------------------------------------------------------------------------------------------*/
function MuestraCalendario(id, directorio) {
    $("#" + id).datepicker({
        changeMonth: true,
        changeYear: true,
        showOtherMonths: true,
        selectOtherMonths: true,
        showOn: "button",
        buttonImage: directorio +"Imagenes/imgCalendario.gif",
        buttonImageOnly: true,
        dateFormat: "yy-mm-dd"
    });
}

/*Mostrar Mensaje-----------------------------------------------------------------------------------------
texto: contenido del mensaje en html
tipo: Advertencia, Alerta, Error, Información, Pare
titulo: Título de la ventana del mensaje, si está vacío 
        aparece un título por defecto
directorio: url en donde se encuentra la imagen
Ej: MostrarMensaje('Error en el sistema<br />Inicie nuevamente.', 'Error', '','')
Campos opcionales:
idFoco: id del objeto en el cual debe estar el foco luego de cerrar el mensaje
funcion: nombre de la funcion que se desea ejecutar luego de cerrar el mensaje
Ej: MostrarMensaje('Error en el sistema<br />Inicie nuevamente.', 'Error', '','txtNumero','LimpiaNumero()')
----------------------------------------------------------------------------------------------------------*/
function MostrarMensaje(texto, tipo, titulo, directorio, idFoco, funcion) {
    if (titulo == '') {
        titulo = 'Mensaje del sistema';
    }
    /*Contenido del mensaje*/
    var contenido = "<table><tr><td><img id='msgImagen' alt='Imagen' src='" + directorio + "Imagenes/imgMsg" + tipo + ".gif'/>";
    contenido += "</td><td id='msgTexto'>" + texto + "</td></tr></table>";

    $("#divMensaje").dialog({
        modal: true,
        show: "fade",
        resizable: false,
        title: titulo,
        buttons: {
            Ok: function () {
                $(this).dialog("close");
                if (idFoco != null && idFoco != "")
                    $("#" + idFoco).focus();
                if (funcion != null)
                    eval(funcion);
            }            
        },
        close: function () {            
            if (idFoco != null && idFoco != "")
                $("#" + idFoco).focus();
            if (funcion != null)
                eval(funcion);
        }
    });
    $("#divMensaje").html(contenido).dialog("open");
}

/*--------------------------------------------------------------------------------------
Permite marcar todos los registros que se muestran en la grilla para esto se debe tener
un control tipo CHECKBOX en el <HeaderTemplate>  
Ids: el nombre del control grid
Ejm.
<HeaderTemplate>
	<INPUT id="chkNominaTodos" onclick="MarcarTodos('chkNomina')" type="checkbox" CHECKED>
</HeaderTemplate>
ACG
-------------------------------------------------------------------------------------------*/
function MarcarTodos(Ids) {
    for (i = 0; i < document.getElementsByTagName("INPUT").length; i++) {
        var item = document.getElementsByTagName("INPUT")[i];
        if (item.type.toUpperCase() == 'CHECKBOX' && item.id.indexOf(Ids) >= 0) {
            item.checked = event.srcElement.checked
        }
    }
}