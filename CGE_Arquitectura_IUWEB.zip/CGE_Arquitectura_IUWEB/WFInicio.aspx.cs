﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SeguridadAdministradorServicio;
using Talento;
using Seguridad_LogicaNegocio;
using Seguridad_Mensajeria;
using System.Configuration;
using Utilidades;


public partial class WFInicio : clsGeneral
{   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bool retorna = ValidaLlamadoAplicacion();
            if (Session == null || Session["usuId"] == null || Session["sesionId"] == null)
            {                                
                Response.Redirect("WFLogin.aspx");                
            }
            Session["urlQueryLlamadoAplicacion"] = String.Empty;
            Inicio(retorna);            
        }
    }

    /// <summary>
    /// Crea el menú llamado desde alguna aplicación el link
    /// </summary>
    /// <returns></returns>
    bool ValidaLlamadoAplicacion()
    {
        bool retorna = false;
        if (Request.QueryString["login"] != null)
        {
            string tipoIdentificacion = "";
            bool entro = false;

            string ldapPath = ConfigurationManager.AppSettings["LDAP"];
            Utilidades.Ldap ldap = new Ldap(ldapPath);
            Utilidades.Ldap.NetUser[] listaNetUser;
            listaNetUser = ldap.FindAll(Request.QueryString["login"].ToString());
            foreach (Ldap.NetUser netUser in listaNetUser)
            {
                List<Persona> listaPersona = PersonaActor.DameListaPersonaPorUsuarioRedYPorEstado(true, "A", Request.QueryString["login"].ToString(), 0);
                foreach (Persona persona in listaPersona)
                {
                    entro = true;
                    tipoIdentificacion = persona.PersTipoIdentificacion;
                    Session["nombreUsuario"] = netUser.CompleteName;
                    Session["usuIdentificacion"] = netUser.Cedula;
                    Session["persId"] = persona.PersId;
                    Session["login"] = Request.QueryString["login"].ToString();
                }

                UsuarioNegocio usuarioNegocio = new UsuarioNegocio();
                UsuarioBusquedaME meUsuario = new UsuarioBusquedaME();
                UsuarioItemLista usuarioItemLista = new UsuarioItemLista();
                EstadoBusquedaME estadoBusquedaME = new EstadoBusquedaME();

                if (entro)
                {
                    meUsuario.NumeroIdentificacion = netUser.Cedula;
                    estadoBusquedaME.Estado = "A";
                    usuarioItemLista = usuarioNegocio.DevuelveItemListaUsuarioPorIdentificacion(meUsuario, estadoBusquedaME, tipoIdentificacion);

                    foreach (UsuarioItem usuarioItem in usuarioItemLista.UsuarioItem)
                    {
                        if (usuarioItem.NombreEstado.Equals("ACTIVO"))
                        {
                            Session["sesionId"] = Request.QueryString["sesionId"].ToString();
                            if (insertaLogin(usuarioItem.IdUsuario))
                            {
                                retorna = true;
                                Session["usuId"] = usuarioItem.IdUsuario;
                            }
                        }
                        else
                        {
                            UtilidadesGenerales.Alerta("Usuario inactivo en el Módulo de Seguridad.");
                        }
                    }
                }
                else
                    UtilidadesGenerales.Alerta("Existe problemas con la configuración del usuario como Persona.");
            }
        }
        return retorna;
    }
    
    /// <summary>
    /// Guarda en tabla temporal de logeo
    /// </summary>
    /// <param name="login">login a guardar</param>
    /// <returns></returns>
    bool insertaLogin(int usuId)
    {
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        try
        {
            SecuencialME me = new SecuencialME();
            me.Secuencial = usuId;
            srvSeguridadUsuario.EliminaSesionUsuario(me);
        }
        catch
        {            
        }        
        
        try
        {
            bool valido = false;           

            SesionUsuarioMSE sumLogin = new SesionUsuarioMSE();
            ResultadoMS rmLogin = new ResultadoMS();
            sumLogin.IdCodigoUsuario = usuId;
            sumLogin.SesionIdentificador = Session["sesionId"].ToString();
            sumLogin.FechaInicio = DateTime.Now;
            sumLogin.IpMaquina = Request.ServerVariables["REMOTE_ADDR"];

            rmLogin = srvSeguridadUsuario.GuardaUsuarioSesion(sumLogin);

            if (rmLogin.CodigoError != 0)
            {               
                valido = false;
            }
            else
            {
                valido = true;
            }
            return valido;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Ata las validaciones javascripts a los controles e inicializa los combos
    /// </summary>
    void Inicio(bool retorna)
    {
        try
        {
            ddlAplicacion.Attributes.Add("onChange", "inicializaFrame();");
            if (llenaAplicaciones())
            {
                llenaMenu();
                if (retorna)
                {
                    if (Request.QueryString["idApl"] != null)
                    {
                        ListItem item = ddlAplicacion.Items.FindByValue(Request.QueryString["idApl"].ToString());
                        if (item != null)
                        {
                            ddlAplicacion.SelectedValue = Request.QueryString["idApl"].ToString();
                            lblDescripcionFuncional.Text = String.Empty;
                            llenaMenu();
                            llenaCabecera();
                            string script = "$(document).ready(function(){document.getElementById('ContentFrame').src = '" + Session["urlQueryLlamadoAplicacion"].ToString() +"';})";
                            ScriptManager.RegisterClientScriptBlock(this.Page, typeof(UpdatePanel), "inicial", script, true);

                        }
                    }
                }
                else
                {
                    string paginaDefault = ConfigurationManager.AppSettings["aplicacionDefault"].ToString();

                    if (Session["S_strPaginaMenu"] != null)
                    {
                        if (!String.IsNullOrEmpty(paginaDefault))
                        {
                            ListItem item = ddlAplicacion.Items.FindByValue(paginaDefault);
                            if (item != null)
                            {
                                ddlAplicacion.SelectedValue = paginaDefault;
                                lblDescripcionFuncional.Text = String.Empty;
                                llenaMenu();
                                llenaCabecera();
                                string script = "$(document).ready(function(){document.getElementById('ContentFrame').src = '" + Session["S_strPaginaMenu"].ToString() + "';})";
                                ScriptManager.RegisterClientScriptBlock(this.Page, typeof(UpdatePanel), "inicial", script, true);

                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            UtilidadesGenerales.Alerta("--> Existe problemas con la configuración del usuario [" + ex.Message + "]");            
        }
    }

    /// <summary>
    /// Llena el combo de aplicaciones a la cual tiene acceso el usuario
    /// </summary>
    bool llenaAplicaciones()
    {
        bool retorna = true;
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        
        try
        {
            Seguridad_Mensajeria.UsuarioBusquedaME umMenu = new Seguridad_Mensajeria.UsuarioBusquedaME();
                        
            Seguridad_Mensajeria.EstadoBusquedaME ebmMenu = new Seguridad_Mensajeria.EstadoBusquedaME();
            Seguridad_Mensajeria.UsuarioAtribucionesMSLista uamlMenu = new Seguridad_Mensajeria.UsuarioAtribucionesMSLista();
            umMenu.NumeroIdentificacion = Session["usuIdentificacion"].ToString();
            ebmMenu.Ascendente = true;
            uamlMenu = srvSeguridadUsuario.DevuelveItemAtribucionUsuario(umMenu, ebmMenu);


            

            Session["arbol"] = uamlMenu;
            if (uamlMenu.UsuarioAtribucionesMS.Length == 0)
            {                
                //UtilidadesGenerales.Alerta("Existe problemas con la configuración del usuario.");
                retorna = false;
                Session["mensajeSinPerfil"] = System.Configuration.ConfigurationManager.AppSettings["mensajeSinPerfil"].ToString();
                Response.Redirect("WFLogin.aspx");
            }

            foreach (Seguridad_Mensajeria.UsuarioAtribucionesMS listaAplicacion in uamlMenu.UsuarioAtribucionesMS)
            {
                ListItem liEncontro = ddlAplicacion.Items.FindByValue(listaAplicacion.CodigoAplicacion.ToString());
                if (liEncontro == null)
                {                    
                    int auxTamanioTexto = listaAplicacion.NombreAplicacion.Length;
                    if (auxTamanioTexto > 50)
                        auxTamanioTexto = 50;                    
                    ListItem limAplicacion = new ListItem(listaAplicacion.NombreAplicacion.Substring(0, auxTamanioTexto), listaAplicacion.CodigoAplicacion.ToString());
                    ddlAplicacion.Items.Add(limAplicacion);                    
                }
            }
        }
        catch (Exception ex)
        {
            //MostrarMensaje("Existe problemas con la configuración del usuario [" + ex.Message + "]","Error");
            UtilidadesGenerales.Alerta("(1) Existe problemas con la configuración del usuario [" + ex.Message + "]");
            retorna = false;
            //Response.Redirect("WFLogin.aspx");
        }
        

        for (int i = 0; i <= ddlAplicacion.Items.Count - 1; i++)
        {
            ddlAplicacion.Items[i].Attributes.Add("Title", ddlAplicacion.Items[i].Text);
        }
        if (retorna)
            retorna = llenaCabecera();
        
        return retorna;
    }

    /// <summary>
    /// Llena en la cabecera el nombre de la aplicacion y abjo a la derecha del arbol la descripcion
    /// </summary>
    bool llenaCabecera()
    {
        bool retorna = true;
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        
        try
        {
            Seguridad_Mensajeria.SecuencialCortoME smAplicacion = new Seguridad_Mensajeria.SecuencialCortoME();
            Seguridad_Mensajeria.AplicacionMSE amAplicacion = new Seguridad_Mensajeria.AplicacionMSE();
            smAplicacion.Secuencial = (short)Convert.ToInt32(ddlAplicacion.SelectedValue);
            amAplicacion = srvSeguridadUsuario.DevuelveAplicacion(smAplicacion);

            int auxTamanioTexto1 = amAplicacion.Descripcion.Length;
            if (auxTamanioTexto1 > 45)
                auxTamanioTexto1 = 45;
            lblDescAplicacion.Text = amAplicacion.Descripcion.Substring(0, auxTamanioTexto1);
            lblNombreAplicacion.Text = ddlAplicacion.SelectedItem.Text.Substring(3);            
        }
        catch (Exception ex)
        {
            //MostrarMensaje("Existe problemas con la configuración del usuario [" + ex.Message + "]", "Error");
            UtilidadesGenerales.Alerta("(2) Existe problemas con la configuración del usuario [" + ex.Message + "]");
            //Response.Redirect("WFLogin.aspx");
            retorna = false;
        }
        return retorna;
    }

    /// <summary>
    /// Según la aplicación llena el Menú
    /// </summary>
    void llenaMenu()
    {
        try
        {
            string strPaginaMenu = String.Empty;            
            
            trvMenu.Nodes.Clear();
            trvMenu.Dispose();
            
            try
            {
                string[] separadosNombre = Session["nombreUsuario"].ToString().Split(' ');
                lblNombreUsuario.Text = separadosNombre[2] + " " + separadosNombre[0];
            }
            catch
            {
                string[] separadosNombre = Session["nombreUsuario"].ToString().Split(',');
                lblNombreUsuario.Text = separadosNombre[1];
            }

            //lblNombreUsuario.Text = "Bienvenid@! " + lblNombreUsuario.Text + " | " + DateTime.Now.ToLongDateString(); 
            lblNombreUsuario.Text = "Bienvenid@! " + lblNombreUsuario.Text;
            lblFechaSistema.Text = DateTime.Now.ToLongDateString();

            Seguridad_Mensajeria.UsuarioAtribucionesMSLista uamlMenu = (Seguridad_Mensajeria.UsuarioAtribucionesMSLista)Session["arbol"];

            foreach (Seguridad_Mensajeria.UsuarioAtribucionesMS listaArbol in uamlMenu.UsuarioAtribucionesMS)
            {
                if (listaArbol.CodigoAplicacion.ToString().Equals(ddlAplicacion.SelectedValue))
                {
                    strPaginaMenu = listaArbol.Pagina;
                    //Se revisa que la pagina de funcionalidad tiene o no parámetros
                    string queryString = "ip=" + Request.ServerVariables["REMOTE_ADDR"].ToString() + "&s=" + Server.UrlEncode(Session["sesionId"].ToString()) + "&t=" + listaArbol.DescripcionFuncionalidad + "&u=" + Session["usuId"].ToString() + "&idApl=" + listaArbol.CodigoAplicacion + "&idMod=" + listaArbol.CodigoModulo + "&idFun=" + listaArbol.CodigoFuncionalidad + "&persId=" + Session["persId"].ToString() + "&permisos=" + listaArbol.PermisoCosulta + "," + listaArbol.PermisoModifica + "," + listaArbol.PermisoInserta + "," + listaArbol.PermisoElimina + "&login=" + Session["login"].ToString();
                    if (strPaginaMenu.IndexOf('?') > -1)
                        strPaginaMenu = strPaginaMenu + "&" + queryString;
                    else
                        strPaginaMenu = strPaginaMenu + "?" + queryString;

                    if (Request.QueryString["login"] != null)
                    {
                        if ("'" + listaArbol.Pagina + "'" == Request.QueryString["pagina"])
                            Session["urlQueryLlamadoAplicacion"] = strPaginaMenu;
                    }
                    if (ConfigurationManager.AppSettings["aplicacionDefault"].ToString() == listaArbol.CodigoAplicacion.ToString())
                    {
                        if (strPaginaMenu.IndexOf(ConfigurationManager.AppSettings["paginaDefault"].ToString())>-1)
                            Session["S_strPaginaMenu"] = strPaginaMenu;
                    }

                    TreeNode tnAbuelo = new TreeNode(listaArbol.NombreModuloPadre, listaArbol.CodigoModuloPadre.ToString());
                    tnAbuelo.SelectAction = TreeNodeSelectAction.Expand;                    
                    TreeNode tnPadre = new TreeNode(listaArbol.NombreModulo, listaArbol.CodigoModulo.ToString());
                    tnPadre.SelectAction = TreeNodeSelectAction.Expand;
                    TreeNode tnHijo = new TreeNode("- " + listaArbol.NombreFuncionalidad, listaArbol.CodigoFuncionalidad.ToString(), null, strPaginaMenu, "ContentFrame");                    
                    TreeNode find = trvMenu.FindNode(listaArbol.CodigoModuloPadre.ToString());                    
                    if (find == null)
                    {
                        if (listaArbol.CodigoModulo == listaArbol.CodigoModuloPadre)
                        {
                            tnPadre.ChildNodes.Add(tnHijo);
                            this.trvMenu.Nodes.Add(tnPadre);
                        }
                        else
                        {
                            tnPadre.ChildNodes.Add(tnHijo);
                            tnAbuelo.ChildNodes.Add(tnPadre);
                            this.trvMenu.Nodes.Add(tnAbuelo);
                        }
                    }
                    else
                    {
                        bool entro = false;
                        
                            for (int i = 0; i < find.ChildNodes.Count; i++)
                            {
                                if (find.ChildNodes[i].Value == listaArbol.CodigoFuncionalidad.ToString())
                                    entro = true;
                            }

                            for (int i = 0; i < find.ChildNodes.Count; i++)
                            {
                                for (int j = 0; j < find.ChildNodes[i].ChildNodes.Count; j++)
                                {

                                    if (find.ChildNodes[i].ChildNodes[j].Value == listaArbol.CodigoFuncionalidad.ToString())
                                        entro = true;
                                }
                            }


                            if (!entro)
                            {
                                if (find.Value == listaArbol.CodigoModuloPadre.ToString() && find.Text == listaArbol.NombreModuloPadre)
                                {
                                    if (listaArbol.CodigoModulo == listaArbol.CodigoModuloPadre)
                                    {
                                        trvMenu.FindNode(listaArbol.CodigoModuloPadre.ToString()).ChildNodes.Add(tnHijo);
                                    }
                                    else
                                    {
                                        bool flagEncontro = false;
                                        int numChild = 0;

                                        for (int i = 0; i < find.ChildNodes.Count; i++)
                                        {
                                            if (find.ChildNodes[i].Value == listaArbol.CodigoModulo.ToString())
                                            {
                                                flagEncontro = true;
                                                numChild = i;
                                            }
                                        }

                                        if (!flagEncontro)
                                        {
                                            tnPadre.ChildNodes.Add(tnHijo);
                                            trvMenu.FindNode(listaArbol.CodigoModuloPadre.ToString()).ChildNodes.Add(tnPadre);
                                        }
                                        else
                                        {
                                            //trvMenu.FindNode(listaArbol.CodigoModulo.ToString()).ChildNodes.Add(tnHijo);
                                            trvMenu.FindNode(listaArbol.CodigoModuloPadre.ToString()).ChildNodes[numChild].ChildNodes.Add(tnHijo);
                                        }

                                    }
                                }
                            }
                    }
                }
            }

            trvMenu.CollapseAll();
        }
        catch (Exception ex)
        {
            //MostrarMensaje("Existe problemas con la configuración del usuario [" + ex.Message + "]", "Error");
            UtilidadesGenerales.Alerta("(3) Existe problemas con la configuración del usuario [" + ex.Message + "]");
            //Response.Redirect("WFLogin.aspx");
        }
    }

    protected void ddlAplicacion_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblDescripcionFuncional.Text = String.Empty;
        llenaMenu();
        llenaCabecera();        
    }

    protected void imgBotonHome_Click(object sender, ImageClickEventArgs e)
    {
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        try
        {
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "logout", "<script>document.getElementById('logout').value=1;</script>");
            logout.Value = "1";
            Seguridad_Mensajeria.SecuencialME me = new Seguridad_Mensajeria.SecuencialME();
            me.Secuencial = Convert.ToInt32(Session["usuId"]);
            srvSeguridadUsuario.EliminaSesionUsuario(me);
        }
        catch
        {
        }
        
        Session.RemoveAll();
        Response.Redirect("WFLogin.aspx");
    }

    protected void imgBotonCerrar_Click(object sender, ImageClickEventArgs e)
    {
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        try
        {
            Seguridad_Mensajeria.SecuencialME me = new Seguridad_Mensajeria.SecuencialME();
            me.Secuencial = Convert.ToInt32(Session["usuId"]);
            srvSeguridadUsuario.EliminaSesionUsuario(me);
        }
        catch
        {
        }

        string strScript = "<script>window.open('', '_parent', '');window.close();</script>";
        ClientScript.RegisterClientScriptBlock(this.GetType(), "salir", strScript);
    }    
}
