﻿/*******************************************************************************
  Nombre: WFLogin.aspx.cs
  Descripción: Clase que contiene los métodos de la pantalla de logeo al módulo
               centralizado de seguridad
  Creado por: Ing. Miguel Cervantes
  Fecha: Abril/2011
 
  Modificaciones.
      Autor          Fecha                  Descripción
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using Utilidades;
using SeguridadAdministradorServicio;

using Seguridad_LogicaNegocio;
using Seguridad_Mensajeria;
using Talento;


public partial class WFLogin : System.Web.UI.Page
{
    static int usuIdGlobal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["mensajeSinPerfil"] != null)
                lblError.Text = Session["mensajeSinPerfil"].ToString();
            Session.RemoveAll();
            inicio();
        }
    }

    void inicio()
    {
        lblNombreAplicacion.Text = ConfigurationManager.AppSettings["nombreAplicacion"].ToString().Substring(3);
        btnIngresar.Attributes.Add("onClick", "validaCamposLogin(event);");
        txtUsuario.Focus();        
    }
    
    protected void btnIngresar_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        Componentes.ManejadorMensajes objManejaMensaje = new Componentes.ManejadorMensajes();
        string mensajeUserModulo = objManejaMensaje.ObtenerMensajeRecurso(clsConstantes.MsjErr_UserModulo);
        string mensajeErrorIntentos = objManejaMensaje.ObtenerMensajeRecurso(clsConstantes.MsjErr_Intentos);
        string mensajeErrorSeguridad = objManejaMensaje.ObtenerMensajeRecurso(clsConstantes.MsjErr_Seguridad);                
        
        try
        {
            imgLogout.Visible = false;
            Ldap.NetUser netUser = new Ldap.NetUser();
            if (isUserNet(out netUser))
            {                
                string tipoIdentificacion = "";
                bool entro = false;
                List<Persona> listaPersona = PersonaActor.DameListaPersonaPorUsuarioRedYPorEstado(true, "A", txtUsuario.Text, 0);
                foreach(Persona persona in listaPersona)
                {
                    if(persona.PersNumeroIdentificacion == netUser.Cedula)
                    {
                        entro = true;
                        tipoIdentificacion = persona.PersTipoIdentificacion;
                        Session["nombreUsuario"] = netUser.CompleteName;
                        Session["usuIdentificacion"] = netUser.Cedula;
                        Session["persId"] = persona.PersId;
                        Session["login"] = txtUsuario.Text;
                    }
                }

                UsuarioNegocio usuarioNegocio = new UsuarioNegocio();
                UsuarioBusquedaME meUsuario = new UsuarioBusquedaME();
                UsuarioItemLista usuarioItemLista = new UsuarioItemLista();
                EstadoBusquedaME estadoBusquedaME = new EstadoBusquedaME();

                if (entro)
                {
                    meUsuario.NumeroIdentificacion = netUser.Cedula;
                    estadoBusquedaME.Estado = "A";
                    usuarioItemLista = usuarioNegocio.DevuelveItemListaUsuarioPorIdentificacion(meUsuario, estadoBusquedaME, tipoIdentificacion);

                    if (usuarioItemLista.UsuarioItem.Length > 0)
                    {
                        foreach (UsuarioItem usuarioItem in usuarioItemLista.UsuarioItem)
                        {
                            usuIdGlobal = usuarioItem.IdUsuario;
                            if (usuarioItem.NombreEstado.Equals("ACTIVO"))
                            {
                                if (!existeLogeoAnterior(usuarioItem.IdUsuario))
                                {
                                    if (insertaLogin(usuarioItem.IdUsuario))
                                    {
                                        Session["usuId"] = usuarioItem.IdUsuario;
                                        Response.Redirect("WFInicio.aspx", false);
                                    }
                                }
                            }
                            else
                            {
                                lblError.Text = mensajeUserModulo;
                            }
                        }
                    }
                    else
                        lblError.Text = mensajeUserModulo;
                }
                else
                {
                    lblError.Text = mensajeUserModulo;
                }                
            }
            else
            {
                lblReintentos.Text = (Convert.ToInt32(lblReintentos.Text) + 1).ToString();
                if (Convert.ToInt32(lblReintentos.Text) >= 2)
                {
                    string error = mensajeErrorIntentos;
                    lblError.Text = error;
                    foreach (Control c in Page.Controls)
                    {
                        DeshabilitaControl(c);
                    }
                }
                else
                {
                    txtContrasenia.Focus();
                    lblError.Text = mensajeErrorSeguridad;
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }        
    }

    /// <summary>
    /// valida si es usuario de active directory
    /// </summary>
    /// <returns></returns>
    bool isUserNet(out Ldap.NetUser netUser)
    {
        netUser = null;
        try
        {
            bool valido = false;
            string usuario = txtUsuario.Text;
            string dominio = ddlDominio.SelectedItem.Text;
            string ldapPath = ConfigurationManager.AppSettings["LDAP"];

            Ldap ldap = new Ldap(ldapPath);            
            valido = ldap.IsAuthenticated(dominio, usuario, txtContrasenia.Text, out netUser);

            return valido;
        }
        catch
        {
            return false;
        }
    }

    
    /// <summary>
    /// Guarda en tabla temporal de logeo
    /// </summary>
    /// <param name="login">login a guardar</param>
    /// <returns></returns>
    bool insertaLogin(int usuId)
    {        
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        try
        {
            bool valido = false;
            Utilidades.Criptografia cEncripta = new Utilidades.Criptografia(Utilidades.Criptografia.ServiceProviderEnum.TripleDES);
            string sesionEncriptada = cEncripta.Encriptar(Session.SessionID, "cge2011");
            Session["sesionId"] = sesionEncriptada;

            SesionUsuarioMSE sumLogin = new SesionUsuarioMSE();
            ResultadoMS rmLogin = new ResultadoMS();
            sumLogin.IdCodigoUsuario = usuId;
            sumLogin.SesionIdentificador = sesionEncriptada;
            sumLogin.FechaInicio = DateTime.Now;
            sumLogin.IpMaquina = Request.ServerVariables["REMOTE_ADDR"];

            rmLogin = srvSeguridadUsuario.GuardaUsuarioSesion(sumLogin);

            if (rmLogin.CodigoError != 0)
            {
                lblError.Text = rmLogin.Mensaje;
                valido = false;
            }
            else
            {
                valido = true;
            }
            return valido;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Busca si existe registro en la tabla temporal
    /// </summary>
    /// <param name="login">login a buscar</param>
    /// <returns>Retorna true si existe registro en la tabla</returns>
    bool existeLogeoAnterior(int usuId)
    {        
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF

        try
        {
            bool valido = false;

            UsuarioME umAcceso = new UsuarioME();
            EstadoBusquedaME ebmAcceso = new EstadoBusquedaME();
            SesionUsuarioMSELista sumlAcceso = new SesionUsuarioMSELista();

            umAcceso.CodigoUsuario = usuId;

            sumlAcceso = srvSeguridadUsuario.DevuelveSesionUsuario(umAcceso, ebmAcceso);

            foreach (SesionUsuarioMSE sumLista in sumlAcceso.SesionUsuarioMSE)
            {
                Componentes.ManejadorMensajes objManejaMensaje = new Componentes.ManejadorMensajes();
                string mensajeEncuentraLogeado = objManejaMensaje.ObtenerMensajeRecurso(clsConstantes.MsjEncuentraLogeado, sumLista.IpMaquina, sumLista.FechaInicio);
                lblError.Text = mensajeEncuentraLogeado;
                //lblError.Text = "Usted ya se encuentra logeado en la IP " + sumLista.IpMaquina + " desde " + sumLista.FechaInicio + ". Ó finalizó la navegación sin cerrar la aplicación. Por favor cierre la sesión indicada para continuar en el botón inferior.";
                valido = true;
                imgLogout.Visible = true;
            }
            return valido;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            return true;
        }
        
    }

    private void DeshabilitaControl(Control c)
    {
        foreach (Control childc in c.Controls)
        {
            if (childc is TextBox)
            {
                TextBox myTextBox = (TextBox)childc;
                myTextBox.Enabled = false;
                
            }
            if (childc is Button)
            {
                Button myButton = (Button)childc;
                myButton.Enabled = false;

            }
            if (childc is DropDownList)
            {
                DropDownList myDropDownList = (DropDownList)childc;
                myDropDownList.Enabled = false;

            }
            DeshabilitaControl(childc);
        }
    }


    protected void imgLogout_Click(object sender, ImageClickEventArgs e)
    {
        SSeguridad srvSeguridadUsuario = new SSeguridad();//Servicio WCF
        try
        {
            SecuencialME me = new SecuencialME();
            me.Secuencial = usuIdGlobal;
            srvSeguridadUsuario.EliminaSesionUsuario(me);

            Componentes.ManejadorMensajes objManejaMensaje = new Componentes.ManejadorMensajes();
            string mensajeCierreSesionExito = objManejaMensaje.ObtenerMensajeRecurso(clsConstantes.MsjCierreSesionExito);
            
            lblError.Text = mensajeCierreSesionExito;
            imgLogout.Visible = false;
            txtContrasenia.Focus();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }        
    }
}