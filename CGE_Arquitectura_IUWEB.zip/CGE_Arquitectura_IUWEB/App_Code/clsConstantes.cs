﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsContantes
/// </summary>
public class clsConstantes
{
    #region ArchivoRecursos    
    public const string MsjEncuentraLogeado = "Msj_EncuentraLogeado";
    public const string MsjErr_UserModulo = "Err_UserModulo";
    public const string MsjErr_Seguridad = "Err_Seguridad";
    public const string MsjErr_Intentos = "Err_Intentos";
    public const string MsjCierreSesionExito = "Msj_CierreSesionExito";
    #endregion
}