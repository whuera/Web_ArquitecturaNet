﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

/// <summary>
/// Summary description for clsGeneral
/// </summary>
public class clsGeneral : System.Web.UI.Page 
{

    public void MostrarMensaje(string mensaje, string tipo, string idFoco, string funcion)
    {
        string titulo = "Mensaje cgeAplicacionesWEB";
        ScriptManager.RegisterClientScriptBlock(this.Page, typeof(UpdatePanel), "MostrarMensaje", "MostrarMensaje('" + mensaje + "','" + tipo + "','" + titulo + "','../../CGE_Arquitectura_WEB/','" + idFoco + "','" + funcion + "');", true);
    }

    public void MostrarMensaje(string mensaje, string tipo)
    {
        MostrarMensaje(mensaje, tipo, "", "");
    }
}