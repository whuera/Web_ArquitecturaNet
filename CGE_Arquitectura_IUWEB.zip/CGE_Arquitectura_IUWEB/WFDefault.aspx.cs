﻿/*******************************************************************************
  Nombre: WFDefault.aspx.cs
  Descripción: Clase por default para la pantalla de inicio del Frame
  Creado por: Ing. Miguel Cervantes
  Fecha: Abril/2011
 
  Modificaciones.
      Autor          Fecha                  Descripción
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WFDefault : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["usuId"] == null || Session["sesionId"] == null)
            {
                Response.Redirect("WFLogin.aspx", false);
            }
        }
    }
}