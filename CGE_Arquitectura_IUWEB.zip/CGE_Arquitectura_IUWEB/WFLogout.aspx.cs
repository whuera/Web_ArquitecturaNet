﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WFLogout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Abandon();
        ClientScript.RegisterClientScriptBlock(this.GetType(), "close", "<script>window.open('', '_parent', '');window.close();</script>");
    }
}